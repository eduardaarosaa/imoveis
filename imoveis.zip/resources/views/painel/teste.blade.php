@foreach ($property as $item)


{{$item->id}}


@endforeach