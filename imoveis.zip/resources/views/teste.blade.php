@extends('layout')

@section('layoutSite')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h5>Informe os dados do seu imóvel que entraremos em contato</h5>
        </div>
    </div>
    <div class="row">
        <div class='col-md-12'>



        </div>
    </div>
</div>

@endsection