<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Ver Contatos</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                            <tr>

                                <th scope="col">Nome</th>
                                <th scope="col">E-mail</th>
                                <th scope="col">Telefone</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if(count($result) > 0 && isset($result)): ?>
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><a href="<?php echo e(route('visualizar', $row->id)); ?>"><?php echo e($row->nome); ?></a></td>
                                <td><?php echo e($row->email); ?></td>
                                <td><?php echo e($row->telefone); ?></td>

                                <td>
                                    <form action="news1/<?php echo e($row->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="DELETE">
                                        <button type="submit" class="btn btn-success">Apagar </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="7">Nenhum item Cadastrado</td>
                            </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                    <?php echo $result->links(); ?>

                    <a href="<?php echo e(route('home')); ?>">
                        <input type="button" class="btn btn-success" value="Voltar">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\imoveis\resources\views/painel/verContatos.blade.php ENDPATH**/ ?>