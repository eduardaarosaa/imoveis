<?php $__env->startSection('layoutSite'); ?>
<div class="container">
    <div class="row">
    </div>
    <div class="row">
        <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="col-md-4">

            <div class="card" style="width: 18rem;">
                <img src="https://construtoralage.com.br/wp-content/uploads/2019/08/apartamento-2-3-4-quartos.jpg" class=" card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">
                        <?php echo e($row->title); ?></h5>
                    <p class="card-text">
                        <?php echo e($row->description); ?>

                    </p>
                    <h5 class="card-title">
                        <?php echo e($row->value_properties); ?></h5>
                    <a href="#" class="btn btn-success">Clique aqui</a>
                </div>
            </div>
            <br>
        </div>
        <br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br>
    <?php if(isset($dataForm)): ?>

    <?php echo $property->appends($dataForm)->links(); ?>



    <?php else: ?>
    <?php echo $property->links(); ?>


    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\imoveis\resources\views/retornoImovel.blade.php ENDPATH**/ ?>