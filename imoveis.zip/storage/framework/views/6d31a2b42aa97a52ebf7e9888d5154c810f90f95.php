<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Painel de controler</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('addCliente')); ?>"><i class="fas fa-user-plus"></i>
                                    </span>
                                    <h5 class="card-title"> Adicionar clientes</h5></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('consultaClientes')); ?>"><i class="fas fa-search"></i>
                                    </span>
                                    <h5 class="card-title"> Pesquisar cliente</h5></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('addImovel')); ?>"><i class="fas fa-building"></i>
                                    </span>
                                    <h5 class="card-title">Adicionar Imóveis</h5></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('verContatos')); ?>"><i class="fas fa-envelope-open-text"></i>
                                    </span>
                                    <h5 class="card-title">Ver contatos</h5></a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <br>
                    <div class="row">

                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('pesquisarImovel')); ?>"><i class="fas fa-search"></i>
                                    </span>
                                    <h5 class="card-title"> Pesquisar Imóveis</h5></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('queroImovel')); ?>"><i class="fas fa-home"></i>
                                    </span>
                                    <h5 class="card-title">Quero um imóvel</h5></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('venderImovel')); ?>"><i class="far fa-smile-wink"></i>
                                    </span>
                                    <h5 class="card-title">Vender um imóvel</h5></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card" style="width: 12rem;">
                                <div class="card-body" align="center">
                                    <span style="font-size: 3em; color:#101940;">
                                        <a href="<?php echo e(route('config')); ?>"><i class="fas fa-tools"></i>
                                    </span>
                                    <h5 class="card-title">Configurações</h5></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\imoveis\resources\views/home.blade.php ENDPATH**/ ?>