<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Pesquisar um imóvel</div>
                <div class="card-body">
                    <form action="<?php echo e(route('buscaImovel')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex justify-content-center h-100">

                            <input class="form-control" type="text" name="cpf" placeholder="Search...">
                            <button type="submit" class='btn btn-success'>Pesquisar</button>
                    </form>
                </div>
                <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
                <?php endif; ?>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID do cliente</th>
                            <th scope="col">Tipo</th>
                            <th scope="col">Título</th>
                            <th scope="col">Valor</th>
                            <th scope="col">Descrição</th>
                            <th scope="col">Localização</th>
                            <th scope="col">Status</th>
                            <th scope="col">Editar</th>


                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($row->id_client); ?></th>
                            <td><?php echo e($row->tipo); ?></td>
                            <td><?php echo e($row->title); ?></td>
                            <td><?php echo e($row->value_properties); ?></td>
                            <td><?php echo e($row->description); ?></td>
                            <td><?php echo e($row->location); ?></td>
                            <td>
                                <form action="apagar/<?php echo e($row->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-success">Excluir</button>
                                </form>

                            </td>

                            <td>
                                <a href="<?php echo e(route('properties.edit', $row->id)); ?>">
                                    <button type="" class="btn btn-success">Editar</button></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $property->links(); ?>


            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\imoveis\resources\views/painel/pesquisarImovel.blade.php ENDPATH**/ ?>